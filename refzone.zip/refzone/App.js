import React, { useEffect, useState } from 'react';
import { NavigationContainer } from '@react-navigation/native';
import { createNativeStackNavigator } from '@react-navigation/native-stack'; // Usa Native Stack
import AsyncStorage from '@react-native-async-storage/async-storage';
import LoginScreen from './screens/LoginScreen';
import RegisterScreen from './screens/RegisterScreen';
import AdminDashboard from './screens/AdminDashboard';
import RefereeDashboard from './screens/RefereeDashboard';

const Stack = createNativeStackNavigator(); // Native Stack Navigator

export default function App() {
  const [userType, setUserType] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const checkAuth = async () => {
      try {
        const type = await AsyncStorage.getItem('userType');
        setUserType(type);
      } catch (error) {
        console.error('Error:', error);
      } finally {
        setLoading(false);
      }
    };
    checkAuth();
  }, []);

  if (loading) return null;

  return (
    <NavigationContainer>
      <Stack.Navigator>
        {!userType ? (
          <>
            <Stack.Screen 
              name="Login" 
              component={LoginScreen} 
              options={{ headerShown: false }}
            />
            <Stack.Screen 
              name="Register" 
              component={RegisterScreen} 
              options={{ headerShown: false }}
            />
          </>
        ) : userType === 'admin' ? (
          <Stack.Screen 
            name="AdminDashboard" 
            component={AdminDashboard} 
            options={{ headerBackVisible: false }}
          />
        ) : (
          <Stack.Screen 
            name="RefereeDashboard" 
            component={RefereeDashboard} 
            options={{ headerBackVisible: false }}
          />
        )}
      </Stack.Navigator>
    </NavigationContainer>
  );
}