import React, { useState } from 'react';
import { 
  View, 
  Text, 
  FlatList, 
  TouchableOpacity, 
  StyleSheet, 
  Alert 
} from 'react-native';
import AsyncStorage from '@react-native-async-storage/async-storage';

const RefereeDashboard = ({ navigation }) => {
  const [matches, setMatches] = useState([
    {
      id: '1',
      teams: 'Barcelona vs Real Madrid',
      date: '21/03/2025 17:00',
      location: 'Estadio Golwin',
      status: 'POSTULARSE',
    },
    {
      id: '2',
      teams: 'Atlas vs América',
      date: '22/03/2025 18:00',
      location: 'Estadio Golwin',
      status: 'POSTULADO',
    }
  ]);

  const handleApply = (id) => {
    setMatches(matches.map(match => 
      match.id === id ? { ...match, status: 'POSTULADO' } : match
    ));
  };

  const handleLogout = async () => {
    await AsyncStorage.removeItem('userType');
    navigation.replace('Login');
  };

  return (
    <View style={styles.container}>
      <Text style={styles.header}>Partidos Disponibles</Text>

      <FlatList
        data={matches}
        keyExtractor={item => item.id}
        renderItem={({ item }) => (
          <View style={styles.matchCard}>
            <Text style={styles.teams}>{item.teams}</Text>
            <Text style={styles.details}>Fecha: {item.date}</Text>
            <Text style={styles.details}>Ubicación: {item.location}</Text>

            <TouchableOpacity
              style={[
                styles.applyButton,
                item.status === 'POSTULADO' && styles.appliedButton
              ]}
              onPress={() => handleApply(item.id)}
              disabled={item.status === 'POSTULADO'}
            >
              <Text style={styles.buttonText}>{item.status}</Text>
            </TouchableOpacity>
          </View>
        )}
      />

      <TouchableOpacity style={styles.logoutButton} onPress={handleLogout}>
        <Text style={styles.logoutText}>Cerrar sesión</Text>
      </TouchableOpacity>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 20,
    backgroundColor: '#ecf0f1',
  },
  header: {
    fontSize: 24,
    fontWeight: 'bold',
    textAlign: 'center',
    marginVertical: 20,
    color: '#2c3e50',
  },
  matchCard: {
    backgroundColor: '#fff',
    padding: 15,
    borderRadius: 10,
    marginBottom: 15,
    elevation: 2,
  },
  teams: {
    fontSize: 18,
    fontWeight: '600',
    color: '#2c3e50',
    marginBottom: 5,
  },
  details: {
    fontSize: 14,
    color: '#7f8c8d',
    marginVertical: 2,
  },
  applyButton: {
    backgroundColor: '#3498db',
    padding: 10,
    borderRadius: 8,
    marginTop: 10,
    alignItems: 'center',
  },
  appliedButton: {
    backgroundColor: '#95a5a6',
  },
  buttonText: {
    color: '#fff',
    fontWeight: '600',
  },
  logoutButton: {
    backgroundColor: '#e74c3c',
    padding: 12,
    borderRadius: 8,
    alignSelf: 'center',
    marginTop: 20,
  },
  logoutText: {
    color: '#fff',
    fontWeight: '600',
  },
});

export default RefereeDashboard;