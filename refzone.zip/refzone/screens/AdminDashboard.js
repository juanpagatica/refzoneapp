import React, { useState } from 'react';
import { 
  View, 
  Text, 
  FlatList, 
  TouchableOpacity, 
  StyleSheet, 
  Alert 
} from 'react-native';
import AsyncStorage from '@react-native-async-storage/async-storage';

const AdminDashboard = ({ navigation }) => {
  const [matches, setMatches] = useState([
    {
      id: '1',
      teams: 'Barcelona vs Real Madrid',
      date: '21/03/2025 17:00',
      location: 'Estadio Golwin',
      referee: 'Sin asignar',
    }
  ]);

  const handleLogout = async () => {
    await AsyncStorage.removeItem('userType');
    navigation.replace('Login');
  };

  const deleteMatch = (id) => {
    setMatches(matches.filter(match => match.id !== id));
  };

  return (
    <View style={styles.container}>
      <Text style={styles.header}>Panel de Administrador</Text>

      <FlatList
        data={matches}
        keyExtractor={item => item.id}
        renderItem={({ item }) => (
          <View style={styles.matchCard}>
            <Text style={styles.teams}>{item.teams}</Text>
            <Text style={styles.details}>Fecha: {item.date}</Text>
            <Text style={styles.details}>Ubicación: {item.location}</Text>
            <Text style={styles.details}>Árbitro: {item.referee}</Text>

            <View style={styles.buttonsContainer}>
              <TouchableOpacity 
                style={styles.buttonSmall}
                onPress={() => deleteMatch(item.id)}
              >
                <Text>Eliminar</Text>
              </TouchableOpacity>
              <TouchableOpacity style={styles.buttonSmall}>
                <Text>Editar</Text>
              </TouchableOpacity>
            </View>
          </View>
        )}
      />

      <TouchableOpacity style={styles.logoutButton} onPress={handleLogout}>
        <Text style={styles.logoutText}>Cerrar sesión</Text>
      </TouchableOpacity>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 20,
    backgroundColor: '#ecf0f1',
  },
  header: {
    fontSize: 24,
    fontWeight: 'bold',
    textAlign: 'center',
    marginVertical: 20,
    color: '#2c3e50',
  },
  matchCard: {
    backgroundColor: '#fff',
    padding: 15,
    borderRadius: 10,
    marginBottom: 15,
    elevation: 2,
  },
  teams: {
    fontSize: 18,
    fontWeight: '600',
    color: '#2c3e50',
    marginBottom: 5,
  },
  details: {
    fontSize: 14,
    color: '#7f8c8d',
    marginVertical: 2,
  },
  buttonsContainer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginTop: 10,
  },
  buttonSmall: {
    backgroundColor: '#bdc3c7',
    padding: 8,
    borderRadius: 5,
    minWidth: 80,
    alignItems: 'center',
  },
  logoutButton: {
    backgroundColor: '#e74c3c',
    padding: 12,
    borderRadius: 8,
    alignSelf: 'center',
    marginTop: 20,
  },
  logoutText: {
    color: '#fff',
    fontWeight: '600',
  },
});

export default AdminDashboard;